package utility;

public class Constant {
  public static final String DRIVER = "oracle.jdbc.driver.OracleDriver";
  public static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
  public static final String USER = "user1234";
  public static final String PASSWORD = "1234";
}
