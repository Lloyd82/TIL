create table BookList(
    isbn            number(5)       primary key, --도서 번호
    title           varchar2(50)    not null,    --도서 명
    author          varchar2(250)   not null,    --저자
    publisher       varchar2(50)    not null,    --출판사
    price           number(6)       not null,    --가격
    DETAIL          varchar2(200),               --상세
    publish_date    varchar2(10)                --발행일
);
--테이블삭제
--DROP TABLE BOOKLIST;
--데이터삭제
--DELETE FROM BOOKLIST;

SELECT * FROM BOOKLIST;
DESC BOOKLIST;



insert into booklist
(isbn, title, author, publisher, price, detail)
values(21424, 'Java Basic','김하나','jaen.kr',15000,'Java 기본 문법');

insert into booklist
(isbn, title, author, publisher, price, detail)
values(33455, 'JDBC Pro','김철수','jaen.kr',23000,'');

insert into booklist
(isbn, title, author, publisher, price, detail)
values(55355, 'Servlet/jsp','박자바','jaen.kr',41000,'model2 기반');

insert into booklist
(isbn, title, author, publisher, price, detail)
values(35332, 'Android App','홍길동','jaen.kr',25000,'Loghtweight Framework');
--7개컬럼
insert into booklist
(isbn, title, author, publisher, price, detail)
values(35355, 'OOAD 분석 설계','소나무','jaen.kr',30000,'');




SELECT * FROM BOOKLIST
OrDER BY ISBN desc;
